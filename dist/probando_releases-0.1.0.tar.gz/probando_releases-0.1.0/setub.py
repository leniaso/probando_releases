from setuptools import setup, find_packages

setup(
    name="probando_releases",                           # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="leniaso",                         # Tu nombre
    author_email="alejandro.naranjoc@udea.edu.co",                 # Tu correo electrónico
    url="https://github.com/leniaso/probando_releases",     # URL del proyecto
)